# "Suki desu"

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maze-the-bashful/pen/RwzOmWz](https://codepen.io/Maze-the-bashful/pen/RwzOmWz).

